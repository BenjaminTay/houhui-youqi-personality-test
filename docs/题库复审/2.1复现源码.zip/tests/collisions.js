// 运行 node tests/collisions.js，使用生产分类器和同一组随机数对比题库版本。
import { EDITION, questions, profiles } from "../src/content.js";
import { classify, contributions, distances, ideal } from "../src/scoring.js";

const seed = 20261124;
function generator() {
  let state = seed;
  return () => {
    state = (Math.imul(1664525, state) + 1013904223) >>> 0;
    return state / 2 ** 32;
  };
}
const zeros = () => Object.fromEntries(profiles.map((p) => [p.name, 0]));
const presence = zeros(),
  slots = zeros(),
  items = {};
for (const q of questions) {
  const rows = profiles.map((p) => contributions(q, p));
  const winners = q.options.map((_, i) => {
    const peak = Math.max(...rows.map((row) => row[i]));
    return profiles
      .filter((p, j) => peak - rows[j][i] < 1e-9)
      .map((p) => p.name);
  });
  for (const name of new Set(winners.flat())) presence[name]++;
  for (const names of winners) if (names.length === 1) slots[names[0]]++;
  items[q.id] = winners;
}
const random = generator(),
  pairs = {},
  primary = zeros();
const sampleCount = 100000;
for (let i = 0; i < sampleCount; i++) {
  const answers = questions.map(
    (q) => q.options[Math.floor(random() * q.options.length)].id,
  );
  const { main, second, margin } = classify(answers);
  primary[main.name]++;
  const key = [main.name, second.name].sort().join("／");
  const row = (pairs[key] ??= { top2: 0, near: 0 });
  row.top2++;
  if (margin < 1) row.near++;
}
const probeCount = 5000,
  guests = {};
for (const p of profiles) {
  const rng = generator();
  const best = questions.map((q) => {
    const ds = distances(q, p);
    return q.options.filter((_, i) => ds[i] === Math.min(...ds));
  });
  const predicted = zeros();
  for (let i = 0; i < probeCount; i++) {
    const answers = questions.map((q, j) => {
      const pick = rng(),
        noise = rng(),
        any = rng();
      return noise < 0.25
        ? q.options[Math.floor(any * q.options.length)].id
        : best[j][Math.floor(pick * best[j].length)].id;
    });
    predicted[classify(answers).main.name]++;
  }
  const path = ideal(p),
    self = classify(path);
  let retained = 0;
  for (const [i, q] of questions.entries())
    for (const o of q.options) {
      if (o.id === path[i]) continue;
      const changed = [...path];
      changed[i] = o.id;
      retained += Number(classify(changed).main === p);
    }
  guests[p.name] = {
    self: self.main.name,
    runner: self.second.name,
    margin: +self.margin.toFixed(2),
    retained,
    predicted,
  };
}
console.log(
  JSON.stringify(
    {
      edition: EDITION,
      seed,
      sampleCount,
      probeCount,
      primary,
      pairs,
      guests,
      items,
      presence,
      slots,
    },
    null,
    2,
  ),
);
